import Sidebar from "../components/Sidebar";

export default function HistoryPage() {
  return (
    <div className="flex min-h-screen bg-surface text-white">
      <Sidebar />

      <div className="flex-1 p-8">

        <h1 className="text-4xl font-bold mb-6">
          📜 History
        </h1>

        <div className="bg-zinc-900 rounded-xl p-6">

          <p className="text-gray-400">
            No history found.
          </p>

          <p className="mt-3 text-gray-500">
            Your AI Chats, Proposals, Invoices and WhatsApp Replies
            will appear here automatically.
          </p>

        </div>

      </div>

    </div>
  );
}