import Sidebar from "../components/Sidebar";
import { useState } from "react";
import { generateCoverLetter } from "../lib/api";
import jsPDF from "jspdf";
export default function CoverLetterPage() {
    
    const [name, setName] = useState("");
  const [jobRole, setJobRole] = useState("");
  const [company, setCompany] = useState("");
  const [skills, setSkills] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
  setLoading(true);

  const prompt = `
Name: ${name}
Job Role: ${jobRole}
Company: ${company}
Skills: ${skills}
`;

  try {
    const data = await generateCoverLetter(prompt);
    setResult(data.reply);
  } catch (error) {
    alert("Failed to generate cover letter.");
  } finally {
    setLoading(false);
  }
};

const downloadPDF = () => {
  const pdf = new jsPDF();

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(12);

  const lines = pdf.splitTextToSize(result, 180);
  pdf.text(lines, 10, 10);

  pdf.save(`${name || "CoverLetter"}.pdf`);
};

  return (
    <div className="flex min-h-screen bg-surface text-white">
      <Sidebar />

      <div className="flex-1 p-10">
        <h1 className="text-3xl font-bold mb-6">
          AI Cover Letter Generator
        </h1>

        <div className="bg-gray-900 rounded-xl p-6 max-w-3xl space-y-4">

  <input
    type="text"
    placeholder="Your Name"
    value={name}
    onChange={(e) => setName(e.target.value)}
    className="w-full p-3 rounded bg-gray-800"
  />

  <input
    type="text"
    placeholder="Job Role"
    value={jobRole}
    onChange={(e) => setJobRole(e.target.value)}
    className="w-full p-3 rounded bg-gray-800"
  />

  <input
    type="text"
    placeholder="Company Name"
    value={company}
    onChange={(e) => setCompany(e.target.value)}
    className="w-full p-3 rounded bg-gray-800"
  />

  <textarea
    placeholder="Your Skills"
    value={skills}
    onChange={(e) => setSkills(e.target.value)}
    className="w-full p-3 rounded bg-gray-800 h-32"
  />

  <button
    onClick={handleGenerate}
    disabled={loading}
    className="bg-blue-600 px-6 py-3 rounded hover:bg-blue-700"
  >
    {loading ? "Generating..." : "Generate Cover Letter"}
  </button>

  {result && (
  <button
    onClick={downloadPDF}
    className="ml-3 bg-green-600 px-6 py-3 rounded hover:bg-green-700"
  >
    Download PDF
  </button>
)}

  {result && (
    <div className="mt-6 rounded-lg bg-gray-800 p-4 whitespace-pre-wrap">
      {result}
    </div>
  )}

</div>
      </div>
    </div>
  );
}