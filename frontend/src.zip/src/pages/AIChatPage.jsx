import { useState, useEffect } from "react";
import Sidebar from "../components/Sidebar";
import { supabase } from "../lib/supabase";
import { chatWithAI } from "../lib/api";
import {
  saveMessage,
  loadMessages,
  saveMemory,
  loadMemory,
  createChat,
  loadChats,
  updateChatTitle,
} from "../services/Chatservice";

const DAILY_LIMIT = 1000;

export default function AIChatPage() {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([
  {
    role: "assistant",
    text: "👋 Hello! Welcome to CryvixAI. How can I help you today?",
  },
]);

  const [chatId, setChatId] = useState(null);
const [chats, setChats] = useState([]);

  const [loading, setLoading] = useState(false);
  const [remaining, setRemaining] = useState(DAILY_LIMIT);
  const [error, setError] = useState("");
  const [memory, setMemory] = useState("");
  const [user, setUser] = useState(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      setUser(data.user);
      console.log("User:", data.user);
    });
  }, []);
useEffect(() => {
  if (!user) return;

  async function fetchData() {
    try {
      const userMemory = await loadMemory(user.id);
      setMemory(userMemory);

      const userChats = await loadChats(user.id);
      setChats(userChats);
    } catch (err) {
      console.error(err);
    }
  }

  fetchData();
}, [user]);

useEffect(() => {
  if (!chatId) return;

  async function fetchMessages() {
    try {
      const data = await loadMessages(chatId);

      if (data.length > 0) {
        setMessages(
          data.map((msg) => ({
            role: msg.role,
            text: msg.message,
          }))
        );
      } else {
        setMessages([
          {
            role: "assistant",
            text: "👋 Hello! Welcome to CryvixAI. How can I help you today?",
          },
        ]);
      }
    } catch (err) {
      console.error(err);
    }
  }

  fetchMessages();
}, [chatId]);

  

const handleNewChat = async () => {
  try {
    if (!user) return;

    console.log("New Chat clicked");

    const chat = await createChat(user.id, "New Chat");

    console.log("Chat Created:", chat);

    setChatId(chat.id);
    console.log("Current chatId:", chatId);


    setChats((prev) => [chat, ...prev]);

    

    setMessages([
      {
        role: "assistant",
        text: "👋 Hello! Welcome to CryvixAI. How can I help you today?",
      },
    ]);

    return;
  } catch (err) {
    console.error(err);
    alert(err.message);
  }
};


  const handleSend = async () => {
    console.log("Send button clicked");
    
    if (remaining <= 0) {
      setError("🚫 Daily limit reached. Upgrade to CryvixAI Pro.");
      return;
    }

    if (!message.trim()) return;

    const userMessage = message;

    let currentChatId = chatId;

if (!currentChatId) {
  const newChat = await createChat(user.id, "New Chat");
  currentChatId = newChat.id;
  setChatId(currentChatId);

  setChats((prev) => [newChat, ...prev]);
}

    if (user) {
      console.log("Saving with currentChatId:", currentChatId);
console.log("State chatId:", chatId);
      await saveMessage(user.id, currentChatId, "user", userMessage);
      const userChats = await loadChats(user.id);

const currentChat = userChats.find(
  (chat) => chat.id === currentChatId
);

console.log("Current Chat:", currentChat);

if (currentChat && currentChat.title === "New Chat") {
  const newTitle = userMessage.substring(0, 30);

  await updateChatTitle(currentChatId, newTitle);

  setChats((prev) =>
    prev.map((chat) =>
      chat.id === currentChatId
        ? { ...chat, title: newTitle }
        : chat
    )
  );
}

    }

    setMessages((prev) => [
      ...prev,
      {
        role: "user",
        text: userMessage,
      },
    ]);

    setMessage("");
    setRemaining((prev) => prev - 1);

    try {
      setLoading(true);
let finalMessage = userMessage;

if (memory) {
  finalMessage = `User Memory:
${memory}

User: ${userMessage}`;
}
const data = await chatWithAI(
  finalMessage,
  messages.map((msg) => ({
    role: msg.role,
    content: msg.text,
  }))
);

setLoading(false);

      
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: data.reply,
        },
      ]);

      if (user) {

  await saveMessage(user.id, currentChatId, "assistant", data.reply);
  let updatedMemory = memory;

if (
  userMessage.toLowerCase().includes("mera") ||
  userMessage.toLowerCase().includes("my")
) {
  updatedMemory = memory + "\n" + userMessage;

  await saveMemory(user.id, updatedMemory);

  setMemory(updatedMemory);
}

}
    } 
    catch (err) {
  console.error("FULL ERROR:", err);

  alert(
    err?.message || JSON.stringify(err, null, 2)
  );

  setMessages((prev) => [
    ...prev,
    {
      role: "assistant",
      text: "❌ Server se connect nahi ho pa raha.",
    },
  ]);
}
    finally {
  setLoading(false);
}
  };

  

  return (
    <div className="flex min-h-screen bg-surface text-white">
      <Sidebar />

      <div className="flex-1 p-6">
        <div className="max-w-4xl mx-auto">

          <div className="flex justify-between items-center mb-6">

  <h1 className="text-4xl font-bold">
    💬 CryvixAI Chat
  </h1>

  <button
    onClick={handleNewChat}
    className="bg-cyan-500 hover:bg-cyan-600 px-4 py-2 rounded-xl font-semibold"
  >
    ➕ New Chat
  </button>

</div>

{chats.length > 0 && (
  <div className="mb-4">
    {chats.map((chat) => (
      <button
        key={chat.id}
        onClick={() => {
  setMessages([]);
  setChatId(chat.id);
}}
        className="block w-full text-left bg-zinc-800 hover:bg-zinc-700 p-3 rounded-lg mb-2"
      >
        {chat.title}
      </button>
    ))}
  </div>
)}

          <div className="glass rounded-3xl p-6 min-h-[500px]">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`mb-4 ${
                  msg.role === "user"
                    ? "text-right"
                    : "text-left"
                }`}
              >
                <div
                  className={`inline-block rounded-2xl px-4 py-3 ${
                    msg.role === "user"
                      ? "bg-cyan-600"
                      : "bg-zinc-800"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          <div className="mb-3 mt-4 flex justify-between text-sm text-gray-300">
            <span>
              Free Messages Left: {remaining} / {DAILY_LIMIT}
            </span>

            {error && (
              <span className="text-red-400">
                {error}
              </span>
            )}
          </div>
          <div className="flex gap-3 border border-red-500 p-3 rounded-xl">
            <input
              type="text"
              placeholder="Type your message..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 rounded-xl bg-zinc-900 px-4 py-3 outline-none"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSend();
                }
              }}
            />

            <button
              onClick={handleSend}
              className="bg-cyan-500 px-6 rounded-xl font-semibold"
            >
              Send
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}