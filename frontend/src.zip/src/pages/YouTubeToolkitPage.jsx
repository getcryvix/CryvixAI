import { useState } from "react";
import axios from "axios";
import { jsPDF } from "jspdf";

export default function YouTubeToolkitPage() {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generateContent = async () => {
    if (!topic.trim()) {
      alert("Please enter a video topic.");
      return;
    }

    try {
      setLoading(true);

      const response = await axios.post(
        "http://localhost:3001/api/youtube-toolkit",
        {
          topic,
        }
      );

      setResult(response.data.result);
    } catch (error) {
      console.error(error);
      alert("Failed to generate content.");
    } finally {
      setLoading(false);
    }
  };

  const copyResult = async () => {
    if (!result) return;

    await navigator.clipboard.writeText(result);
    alert("Result copied successfully!");
  };

  const clearAll = () => {
    setTopic("");
    setResult("");
  };

  const downloadTxt = () => {
    if (!result) {
      alert("Generate content first.");
      return;
    }

    const blob = new Blob([result], {
      type: "text/plain",
    });

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "CryvixAI-YouTube-Toolkit.txt";
    link.click();

    URL.revokeObjectURL(link.href);
  };

  const downloadPdf = () => {
    if (!result) {
      alert("Generate content first.");
      return;
    }

    const pdf = new jsPDF();

    const lines = pdf.splitTextToSize(result, 180);

    pdf.setFontSize(12);
    pdf.text(lines, 10, 10);

    pdf.save("CryvixAI-YouTube-Toolkit.pdf");
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-2">
        AI YouTube Toolkit
      </h1>

      <p className="text-gray-400 mb-6">
        Generate YouTube Titles, Descriptions, Hashtags,
        Keywords and Thumbnail Prompts using AI.
      </p>

      <div className="bg-gray-900 rounded-xl p-6 border border-gray-700">

        <label className="block mb-2 font-semibold">
          Video Topic
        </label>

        <textarea
          rows={6}
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Example: History of the Roman Empire"
          className="w-full rounded-lg bg-gray-800 border border-gray-700 p-4 outline-none"
        />

        <button
          onClick={generateContent}
          className="mt-5 bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-semibold"
        >
          {loading ? "Generating..." : "Generate Content"}
        </button>
      </div>
      <div className="mt-8 bg-gray-900 rounded-xl p-6 border border-gray-700">

        <h2 className="text-xl font-bold mb-4">
          AI Result
        </h2>

        <div className="flex flex-wrap gap-3 mb-4">

          <button
            onClick={copyResult}
            className="rounded-lg bg-green-600 px-4 py-2 font-semibold hover:bg-green-700"
          >
            📋 Copy
          </button>

          <button
            onClick={clearAll}
            className="rounded-lg bg-red-600 px-4 py-2 font-semibold hover:bg-red-700"
          >
            🧹 Clear
          </button>

          <button
            onClick={downloadTxt}
            className="rounded-lg bg-purple-600 px-4 py-2 font-semibold hover:bg-purple-700"
          >
            📄 Download TXT
          </button>

          <button
            onClick={downloadPdf}
            className="rounded-lg bg-orange-600 px-4 py-2 font-semibold hover:bg-orange-700"
          >
            📕 Download PDF
          </button>

        </div>

        <pre className="whitespace-pre-wrap text-gray-300">
          {result || "Your generated YouTube content will appear here."}
        </pre>

      </div>
    </div>
  );
}