import { useState } from "react";
import Sidebar from "../components/Sidebar";
import { summarizeDocument } from "../api/documentApi";

export default function DocumentSummarizerPage() {

const [file,setFile]=useState(null);
const [summary,setSummary]=useState("");
const [loading,setLoading]=useState(false);

async function handleSummarize(){

if(!file){
alert("Select a document");
return;
}

const formData=new FormData();

formData.append("file",file);

try{

setLoading(true);

const result=await summarizeDocument(formData);

setSummary(result);

}
catch{

alert("Summarization failed");

}
finally{

setLoading(false);

}

}

return(

<div className="flex min-h-screen bg-surface text-white">

<Sidebar/>

<div className="flex-1 p-10">

<h1 className="text-4xl font-bold mb-8">

AI Document Summarizer

</h1>

<div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">

<input

type="file"

accept=".pdf,.doc,.docx,.txt"

onChange={(e)=>setFile(e.target.files[0])}

/>

<button

onClick={handleSummarize}

className="mt-6 bg-cyan-600 px-8 py-3 rounded-xl"

>

{loading?"Summarizing...":"Summarize"}

</button>

<textarea

readOnly

value={summary}

className="mt-6 w-full h-72 bg-zinc-800 rounded-xl p-4"

/>

</div>

</div>

</div>

);

}