import { useState, useEffect } from "react";
export default function ImagePage() {
  const [prompt, setPrompt] = useState("");
  const [images, setImages] = useState([]);
  const [enhancing, setEnhancing] = useState(false);
  const [style, setStyle] = useState("Realistic");
  const [size, setSize] = useState("Square");
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(false);
 const [history, setHistory] = useState([]);
 const [preview, setPreview] = useState("");
 
  useEffect(() => {
  const savedHistory = localStorage.getItem("imageHistory");

  

  if (savedHistory) {
    setHistory(JSON.parse(savedHistory));
  }
}, []);

useEffect(() => {
  if (history.length > 0) {
    
    localStorage.setItem("imageHistory", JSON.stringify(history));
  }
}, [history]);
  const generateImage = async () => {
    if (!prompt.trim()) return;
    setEnhancing(true);
await new Promise((resolve) => setTimeout(resolve, 1000));

    setLoading(true);
    setImage("");

    try {
      const enhancedPrompt = prompt.trim();
      const finalPrompt = `${style} style, ultra detailed, masterpiece, best quality, highly realistic, ${enhancedPrompt}`;

      const res = await fetch("/api/image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt: finalPrompt,
          size,
        }),
      });

      const data = await res.json();

      if (data.image) {
        setImage(data.image);
        
        setImages((prev) => [data.image, ...prev].slice(0, 4));

        setHistory((prev) => [
        data.image,
        ...prev,
    ]);
  

        
      } else {
        alert(data.error || "Image generation failed");
      }
    } catch {
      alert("Server Error");
    }
    setEnhancing(false);

    setLoading(false);
  };
  const downloadImage = async () => {
  if (!image) return;

  try {
    const response = await fetch(image);
    const blob = await response.blob();

    const url = window.URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `CryvixAI-${Date.now()}.png`;

    document.body.appendChild(a);
    a.click();

    a.remove();
    window.URL.revokeObjectURL(url);
  } catch (err) {
    alert("Download failed");
  }
};
const copyPrompt = async () => {
  try {
    await navigator.clipboard.writeText(prompt);
    alert("✅ Prompt copied!");
  } catch {
    alert("Copy failed");
  }
};

const clearHistory = () => {
  if (window.confirm("Delete all image history?")) {
    setHistory([]);
    localStorage.removeItem("imageHistory");
  }
};

  return (
    <div className="p-8 text-white max-w-5xl mx-auto">
      <h1 className="text-4xl font-bold mb-6">
        🎨 AI Image Generator
      </h1>

      <textarea
        className="w-full p-4 rounded-xl text-black"
        rows={4}
        placeholder="Describe the image you want..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />

      <select
        className="mt-4 w-full p-3 rounded-xl text-black"
        value={style}
        onChange={(e) => setStyle(e.target.value)}
      >
        <option>Realistic</option>
        <option>Anime</option>
        <option>3D Render</option>
        <option>Cartoon</option>
        <option>Cinematic</option>
      </select>
      <select
  className="mt-4 w-full p-3 rounded-xl text-black"
  value={size}
  onChange={(e) => setSize(e.target.value)}
>
  <option>Square</option>
  <option>Portrait</option>
  <option>Landscape</option>
</select>

      <button
        onClick={generateImage}
        disabled={loading}
        className="mt-4 bg-cyan-500 px-6 py-3 rounded-xl disabled:opacity-50"
      >
        {enhancing
  ? "✨ Enhancing Prompt..."
  : loading
  ? "🎨 Generating..."
  : "Generate Image"}
      </button>

      {images.length > 0 && (
  <div className="mt-8">
    {images.map((img, index) => (
      <img
        key={index}
        src={img}
        alt="Generated AI Image"
        onClick={() => setPreview(img)}
        className="rounded-xl w-full max-w-xl cursor-pointer"
      />
    ))}
  </div>
)}

          <button
  onClick={downloadImage}
  className="mt-4 bg-green-600 hover:bg-green-700 px-6 py-3 rounded-xl"
>
  ⬇ Download Image
</button>

<button
  onClick={copyPrompt}
  className="mt-3 ml-3 bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-xl"
>
  📋 Copy Prompt
</button>


      {history.length > 0 && (
  <div className="mt-10">
    <div className="flex justify-between items-center mb-4">
  <h2 className="text-2xl font-bold">
    🖼 Image History
  </h2>

  <button
    onClick={clearHistory}
    className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg"
  >
    🗑 Clear History
  </button>
</div>

    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {history.map((img, index) => (
        <img
          key={index}
          src={img}
          alt={`History ${index}`}
          onClick={() => setPreview(img)}
          className="rounded-xl cursor-pointer"
        />
      ))}
    </div>
  </div>
)}
{preview && (
        <div
            className="fixed inset-0 bg-black z-50 flex items-center justify-center"
          onClick={() => setPreview("")}
        >
          <img
            src={preview}
            alt="Preview"
            className="w-screen h-screen object-contain"
          />
        </div>
      )}
    </div>
    );
}
  