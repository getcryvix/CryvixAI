import Sidebar from "../components/Sidebar";
import { useState } from "react";
import jsPDF from "jspdf";
import { generateResume } from "../lib/api";
export default function ResumeBuilderPage() {
const [name, setName] = useState("");
const [jobRole, setJobRole] = useState("");
const [skills, setSkills] = useState("");
const [experience, setExperience] = useState("");
const [education, setEducation] = useState("");
const [result, setResult] = useState("");
const [loading, setLoading] = useState(false);
const handleGenerate = async () => {
  setLoading(true);

  const prompt = `
Name: ${name}
Job Role: ${jobRole}
Skills: ${skills}
Experience: ${experience}
Education: ${education}
`;

  try {
    const data = await generateResume(prompt);
    setResult(data.reply);
  } catch (err) {
    setResult("❌ Resume generate nahi ho saka.");
  }

  setLoading(false);
};
const downloadPDF = () => {
  const pdf = new jsPDF();

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(12);

  const lines = pdf.splitTextToSize(result, 180);
  pdf.text(lines, 10, 10);

  pdf.save(`${name || "Resume"}.pdf`);
};

  return (
    <div className="flex min-h-screen bg-surface text-white">
      <Sidebar />

      <div className="flex-1 p-10">
        <h1 className="text-3xl font-bold mb-6">
          AI Resume Builder
        </h1>

        <div className="bg-gray-900 rounded-xl p-6 space-y-4 max-w-3xl">

          <input
            type="text"
            placeholder="Full Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 rounded bg-gray-800"
          />

          <input
            type="text"
            placeholder="Job Role"
            value={jobRole}
onChange={(e) => setJobRole(e.target.value)}
            className="w-full p-3 rounded bg-gray-800"
          />

          <textarea
            placeholder="Skills"
            value={skills}
onChange={(e) => setSkills(e.target.value)}
            rows={3}
            className="w-full p-3 rounded bg-gray-800"
          />

          <textarea
            placeholder="Experience"
            value={experience}
onChange={(e) => setExperience(e.target.value)}
            rows={4}
            className="w-full p-3 rounded bg-gray-800"
          />

          <textarea
            placeholder="Education"
            value={education}
onChange={(e) => setEducation(e.target.value)}
            rows={3}
            className="w-full p-3 rounded bg-gray-800"
          />

          <button 
          onClick={handleGenerate}
disabled={loading} className="bg-blue-600 px-6 py-3 rounded-lg hover:bg-blue-700">
            Generate Resume
          </button>
          
          {result && (
  <button
    onClick={downloadPDF}
    className="mt-4 ml-3 bg-green-600 px-6 py-3 rounded-lg hover:bg-green-700"
  >
    Download PDF
  </button>
)}

          {result && (
  <div className="mt-6 rounded-lg bg-gray-800 p-4 whitespace-pre-wrap">
    {result}
  </div>
)}

        </div>
      </div>
    </div>
  );
}