import { useState } from "react";
import Sidebar from "../components/Sidebar";
import { translateText } from "../api/translatorApi";

const languages = [
  "Auto Detect",
  "English",
  "Hindi",
  "Urdu",
  "French",
  "German",
  "Spanish",
  "Italian",
  "Japanese",
  "Chinese",
  "Russian",
  "Arabic",
];

export default function TranslatorPage() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [fromLanguage, setFromLanguage] =
    useState("Auto Detect");
  const [toLanguage, setToLanguage] =
    useState("English");
  const [loading, setLoading] =
    useState(false);

  async function handleTranslate() {
    if (!input.trim()) return;

    try {
      setLoading(true);

      const result = await translateText(
        input,
        fromLanguage,
        toLanguage
      );

      setOutput(result);
    } catch (err) {
      alert("Translation Failed");
    } finally {
      setLoading(false);
    }
  }

  function swapLanguages() {
    if (fromLanguage === "Auto Detect") return;

    const a = fromLanguage;

    setFromLanguage(toLanguage);
    setToLanguage(a);

    setInput(output);
    setOutput(input);
  }

  return (
    <div className="flex min-h-screen bg-surface text-white">
      <Sidebar />

      <div className="flex-1 p-10">

        <h1 className="text-4xl font-bold mb-8">
          AI Translator
        </h1>

        <div className="bg-zinc-900 rounded-2xl p-6 border border-zinc-800">

          <div className="grid grid-cols-2 gap-4">

            <select
              value={fromLanguage}
              onChange={(e)=>setFromLanguage(e.target.value)}
              className="bg-zinc-800 p-3 rounded-xl"
            >
              {languages.map((lang)=>(
                <option key={lang}>
                  {lang}
                </option>
              ))}
            </select>

            <select
              value={toLanguage}
              onChange={(e)=>setToLanguage(e.target.value)}
              className="bg-zinc-800 p-3 rounded-xl"
            >
              {languages.map((lang)=>(
                <option key={lang}>
                  {lang}
                </option>
              ))}
            </select>

          </div>

          <button
            onClick={swapLanguages}
            className="mt-4 bg-cyan-600 px-4 py-2 rounded-xl"
          >
            🔄 Swap
          </button>

          <textarea
            value={input}
            onChange={(e)=>setInput(e.target.value)}
            placeholder="Enter text..."
            className="mt-6 w-full h-40 rounded-xl bg-zinc-800 p-4"
          />

          <button
            onClick={handleTranslate}
            className="mt-5 bg-green-600 px-8 py-3 rounded-xl"
          >
            {loading ? "Translating..." : "Translate"}
          </button>

          <textarea
            value={output}
            readOnly
            className="mt-6 w-full h-40 rounded-xl bg-zinc-800 p-4"
          />

        </div>

      </div>
    </div>
  );
}