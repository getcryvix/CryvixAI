import axios from "axios";

const API =
  import.meta.env.VITE_API_URL || "http://localhost:3001";

export async function summarizeDocument(formData) {
  const response = await axios.post(
    `${API}/api/document-summary`,
    formData,
    {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    }
  );

  return response.data.summary;
}