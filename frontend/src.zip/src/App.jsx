import { useEffect, useState } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import ForgotPasswordPage from './pages/ForgotPasswordPage'
import DashboardPage from './pages/DashboardPage'
import AIChatPage from './pages/AIChatPage'
import ImagePage from './pages/ImagePage'
import AIWriterPage from './pages/AIWriterPage'
import InvoicePage from "./pages/InvoicePage";
import WhatsAppPage from "./pages/WhatsAppPage";
import ProposalPage from "./pages/ProposalPage";
import HistoryPage from "./pages/HistoryPage";
import ProfilePage from "./pages/ProfilePage";
import ImageAnalyzerPage from "./pages/ImageAnalyzerPage";
import YouTubeToolkitPage from "./pages/YouTubeToolkitPage";
import AICodeAssistantPage from "./pages/AICodeAssistantPage";
import EmailWriterPage from "./pages/EmailWriterPage";
import ResumeBuilderPage from "./pages/ResumeBuilderPage";
import CoverLetterPage from "./pages/CoverLetterPage";
import PDFChatPage from "./pages/PDFChatPage";
import VoiceToTextPage from "./pages/VoiceToTextPage";
import TextToSpeechPage from "./pages/TextToSpeechPage";
import TranslatorPage from "./pages/TranslatorPage";
import DocumentSummarizerPage from "./pages/DocumentSummarizerPage";
import PresentationGeneratorPage from "./pages/PresentationGeneratorPage";
import WebsiteBuilderPage from "./pages/WebsiteBuilderPage";
import { supabase } from './lib/supabase'

function ProtectedRoute({ children, session, loading }) {
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-surface px-4 text-white">
        <div className="glass rounded-3xl px-8 py-6 text-center shadow-2xl shadow-black/40">
          <p className="text-sm uppercase tracking-[0.3em] text-white/40">Loading</p>
          <p className="mt-2 text-lg font-semibold">Checking your session...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return <Navigate to="/login" replace />
  }

  return children
}

function PublicRoute({ children, session, loading }) {
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-surface px-4 text-white">
        <div className="glass rounded-3xl px-8 py-6 text-center shadow-2xl shadow-black/40">
          <p className="text-sm uppercase tracking-[0.3em] text-white/40">Loading</p>
          <p className="mt-2 text-lg font-semibold">Preparing your workspace...</p>
        </div>
      </div>
    )
  }

  if (session) {
    return <Navigate to="/dashboard" replace />
  }

  return children
}

export default function App() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let isMounted = true

    const initializeAuth = async () => {
      const {
  data: { session: currentSession },
} = await supabase.auth.getSession()
  

      if (isMounted) {
        setSession(currentSession)
        setLoading(false)
      }
    }

    initializeAuth()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, currentSession) => {
      if (isMounted) {
        setSession(currentSession)
        setLoading(false)
      }
    })

    return () => {
      isMounted = false
      subscription?.unsubscribe?.()
    }
  }, [])

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route
          path="/login"
          element={
            <PublicRoute session={session} loading={loading}>
              <LoginPage />
            </PublicRoute>
          }
        />
        <Route
          path="/signup"
          element={
            <PublicRoute session={session} loading={loading}>
              <SignupPage />
            </PublicRoute>
          }
        />
        <Route
          path="/forgot-password"
          element={
            <PublicRoute session={session} loading={loading}>
              <ForgotPasswordPage />
            </PublicRoute>
          }
        />
        <Route
  path="/dashboard"
  element={
    <ProtectedRoute session={session} loading={loading}>
      <DashboardPage session={session} />
    </ProtectedRoute>
  }
/>

<Route path="/ai-chat" element={<AIChatPage />} />
<Route path="/invoice" element={<InvoicePage />} />
<Route path="/whatsapp" element={<WhatsAppPage />} />
<Route path="/proposal" element={<ProposalPage />} />
<Route path="/history" element={<HistoryPage />} />
<Route path="/profile" element={<ProfilePage />} />
<Route path="/image-analyzer" element={<ImageAnalyzerPage />} />
<Route path="/ai-writer" element={<AIWriterPage />} />
<Route path="/youtube-toolkit" element={<YouTubeToolkitPage />} />
<Route path="/ai-code" element={<AICodeAssistantPage />} />
<Route path="/email-writer" element={<EmailWriterPage />} />
<Route path="/resume-builder" element={<ResumeBuilderPage />} />
<Route path="/cover-letter" element={<CoverLetterPage />} />
<Route path="/pdf-chat" element={<PDFChatPage />} />
<Route path="/voice-to-text" element={<VoiceToTextPage />} />
<Route path="/text-to-speech" element={<TextToSpeechPage />} />
<Route path="/translator" element={<TranslatorPage />} />
<Route
  path="/document-summary"
  element={<DocumentSummarizerPage />}
/>
<Route
  path="/presentation-generator"
  element={<PresentationGeneratorPage />}
/>
<Route
  path="/website-builder"
  element={<WebsiteBuilderPage />}
/>
<Route path="*" element={<Navigate to="/" replace />} />

</Routes>
    </BrowserRouter>
  )
}
